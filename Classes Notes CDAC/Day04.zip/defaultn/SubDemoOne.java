package defaultn;
class Super{
	
	int x =90; //
	int y=20; //
	int z=1000;
	void show() {
		System.out.println("parent show");
	}
	void display() {
		System.out.println("parent display");
	}
}
public class SubDemoOne extends Super {
    int x =76;
    int y =43;
    void display() {
		System.out.println("child display");
		super.display();
		System.out.println(super.x);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SubDemoOne obj = new SubDemoOne();
		obj.display();
//		System.out.println("value of x="+obj.x);
//		System.out.println("value of x="+obj.z);
		
		
	}

}
