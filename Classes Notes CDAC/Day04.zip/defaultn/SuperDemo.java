package defaultn;

class Parent{
	int x=90;
	void show() {
		System.out.println("parent class");
	}
}

public class SuperDemo extends Parent{
	int x=87;
//    void m1() {
//    	System.out.println(this.x);
//    	//System.out.println(super.x);
//    	System.out.println("child class method");
//    }
	void show() {
		super.show();
		System.out.println("child class");
		super.show();
	}
	public static void main(String[] args) {
		
		SuperDemo obj = new SuperDemo();
		obj.show();
		//obj.m1();

	}

}
