package defaultn;
class Parent1{
//	Parent1(int a){
//		System.out.println("parent const"+a);
//	}
	void v1() {
		System.out.println("parent");
	}
	
	
}
public class Child extends Parent1{
//	Child(int a,int b){
////		super(b);
//		System.out.println("child const"+a);
//	}
	void v2() {
		System.out.println("child");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Child obj = new Child(56,67);
		Parent1 p = new Child();
		p.v1();
	}

}
