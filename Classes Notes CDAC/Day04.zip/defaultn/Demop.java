package defaultn;

public class Demop {
	int x =10;
	Demop(){
		this(45);
		System.out.println("no args");
	
	}
	Demop(int a){
		this(45.87f);
		System.out.println("one argu int="+a);
	}
	Demop(float b){
		System.out.println("one argu float="+b);
		}
	
	public static void main(String[] args) {
		int x=90;
		Demop obj = new Demop();
		System.out.println("value of x="+x);
		System.out.println("value of x="+obj.x);
		

	}

}
