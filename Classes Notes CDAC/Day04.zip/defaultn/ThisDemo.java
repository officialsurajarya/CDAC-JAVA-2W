package defaultn;
// this keyword use
public class ThisDemo {
//	int a;
//	void f1(int a)
//	{
//		this.a =a;
//	}
//	void show() {
//		System.out.println("value of a="+a);
//	}
//	void display() {
//		this.show();
//		System.out.println("after calling teh another method in same class");
//	}
	ThisDemo (){
		this(90);
		System.out.println("no argument");
	}
	ThisDemo(int a){
		//this();
		System.out.println("with args");
	}
	
	public static void main(String[] args) {
		ThisDemo obj = new ThisDemo();
//		obj.f1(73);
//		//obj.show();
//		obj.display();
		
	}

}
