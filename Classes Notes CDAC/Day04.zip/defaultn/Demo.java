package defaultn;
// example of overloading

class Shape{
	void show() {
		System.out.println("parent method");
	}
}
public class Demo extends  Shape{
//	void show() {
//			
//    }
	void show() {
		System.out.println("child");
		super.show();
	}
	public static void main(String[] args) {
		Demo obj = new Demo();
		obj.show();
//		obj.show(56);

	}

}
