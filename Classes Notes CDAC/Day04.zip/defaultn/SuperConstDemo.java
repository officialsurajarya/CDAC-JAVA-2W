package defaultn;
class ParentNew{
	ParentNew(){
		System.out.println("parent clas const");
	}
}
public class SuperConstDemo extends ParentNew {
	SuperConstDemo(int a){
//		super(a);
		
		System.out.println("child clas const"+a);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SuperConstDemo obj = new SuperConstDemo(45);

	}

}
