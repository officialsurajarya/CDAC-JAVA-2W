public class ToLowerCaseExample {
    public static void main(String[] args) {

        String str = "JaVa Programming";
        String lower = str.toLowerCase();
        // String upper = str.toUpperCase();

        System.out.println("Original String: " + str);
        System.out.println("Lowercase String: " + lower);
        // System.out.println("UpperCase String: " + upper);
    }
}
