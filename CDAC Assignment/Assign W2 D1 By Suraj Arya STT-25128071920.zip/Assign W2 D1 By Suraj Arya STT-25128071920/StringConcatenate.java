public class StringConcatenate {
    public static void main(String[] args) {

        String str1 = "This is STT";
        String str2 = "Java class";

        String result = str1 + " " + str2;

        System.out.println("String 1: " + str1);
        System.out.println("String 2: " + str2);
        System.out.println("The concatenated string: " + result);
    }
}
