public class StringToInteger {
    public static void main(String[] args) {

        String str = "123";
        Integer num = Integer.valueOf(str);

        System.out.println("String: " + str);
        System.out.println("Integer: " + num);
    }
}
