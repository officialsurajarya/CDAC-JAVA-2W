abstract class Shape {

    Shape() {
        System.out.println("Abstract class called by constructor");
    }

    abstract void draw();
}

class Circle extends Shape {

    Circle() {
        System.out.println("Circle class called by constructor");
    }

    @Override
    void draw() {
        System.out.println("Drawing Circle");
    }
}

public class AbstractConstructor {
    public static void main(String[] args) {
        Shape s = new Circle();
        s.draw();
    }
}
