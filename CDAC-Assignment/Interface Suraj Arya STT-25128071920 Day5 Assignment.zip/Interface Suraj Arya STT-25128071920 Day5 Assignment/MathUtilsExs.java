interface MathUtils {

    static int square(int x) {
        return x * x;
    }
}

public class MathUtilsExs {
    public static void main(String[] args) {

        int result = MathUtils.square(12);
        System.out.println("Square = " + result);
    }
}
