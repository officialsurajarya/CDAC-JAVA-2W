interface Printer {
    void print();
}

interface Scanner {
    void scan();
}

class AllInOneDevice implements Printer, Scanner {

    @Override
    public void print() {
        System.out.println("Printing docs");
    }

    @Override
    public void scan() {
        System.out.println("Scanning docs");
    }
}

public class MultipleInterface {
    public static void main(String[] args) {

        AllInOneDevice device = new AllInOneDevice();

        device.print();
        device.scan();
    }
}
