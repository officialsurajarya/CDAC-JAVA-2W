interface Calculator {
    int add(int a, int b);

    int subtract(int a, int b);
}

class SimpleCalculator implements Calculator {

    @Override
    public int add(int a, int b) {
        return a + b;
    }

    @Override
    public int subtract(int a, int b) {
        return a - b;
    }
}

public class BasicCalculator {
    public static void main(String[] args) {

        Calculator calc = new SimpleCalculator();

        System.out.println("Addition = " + calc.add(10, 5));
        System.out.println("Subtraction = " + calc.subtract(10, 5));
    }
}
