interface Greeting {

    default void sayHello() {
        System.out.println("Helloo");
    }
}

class EnglishGreeting implements Greeting {

    @Override
    public void sayHello() {
        System.out.println("Hello in Eng!");
    }
}

public class GreetingDemo {
    public static void main(String[] args) {

        Greeting g = new EnglishGreeting();
        g.sayHello();
    }
}
