public class ArrLinearSearch {
    public static void main(String[] args) {

        int arr[] = { 2, 5, 3, 1, 6, 4, 3, 2 };
        int find = 4;

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == find) {
                System.out.println("Element found at index: " + (i));
            } else {
            }
        }
    }
}
